
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/NewScript');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/NewScript.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6db9a2dz5dHr7xYK6/2RtYC', 'NewScript');
// NewScript.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var list = [
    '这才叫肉 夹 馍通常情况下，麦当劳的每种菜品在量上都有相对明确的要求，以保证无论何时何地出品的食物都能质量趋于一致。而这次网友们买到的肉夹馍里的肉多少不一，很可能是因为作为一款新品上市过于匆忙，并没能制定出合理、严格的标准，导致你在不同的门店买的夹肉馍肉量完全看该店的良心或备餐师傅们的心情。每个鸡块的差别不会太大此后，麦当劳摆出了一副“有事好商量”的态度，在微博上表示肉馅的分量可能有所偏差',
    '666666沙拉酱和番茄酱，给汉堡化妆的部分就完成了。不过这还不够，和人一样，要想让它成为广告上的大明星，还得用P图软件给它美颜，去掉面包上的小孔，让它“皮肤细腻有光泽”才行。同样，蜂蜜从松饼上缓缓流下来的镜头看起来很诱人，但真的蜂蜜会被松饼吸收，留下一种神似尿床的印迹，因此聪明的摄影师们想到了用不会被吸收的机油来代替蜂蜜。而广告中啤酒和汽',
    '55555本质上是活在广告素材中的幻影，只要负责美美的就行了，“网络奔现”就别指望了~就拿汉堡来说，要做出广告中那样饱满挺拔的汉堡可不容易。首先要选不管好吃与否，至少严重超模、厚实匀称的粗大肉饼，再专门刷一层油上去让其更多汁、闪亮。然后摆好生菜和西红柿的位置，拿牙签固定住，分布必须符合黄金分割~最后用化妆棉给它穿个内增高，再拿针管在合适的位置挤上',
    '44444广告图与食物很一致就算是经常被网友调侃“封面欺诈”的康师傅也“洗心革面”，开了线下面馆，喊出口号就是要把包装上的红烧牛肉面端到你面前。那么如果足够努力，花多点钱，是不是有一天我们就能有机会吃到广告中那种令人垂涎的美食呢？很可惜，答案是不太可能！这样的巨无霸真的存在吗？广告中的那些美食虽然看起来令人垂涎欲滴、食欲大增，但很多其实根本就不存在',
    '999你说她为社会的进步贡献了多少。我的梦想就是要成为男版的咪蒙，通过骂女性走上人生巅峰。”“所以是为了挣钱？”——“小伙子，你的悟性很高嘛！要不要跟着我，我有个实习生一个月工资五万，我看你根骨不错，是个万中无一的练武奇才。”“好啊好啊，您用这一套去骂女性，等您骂完了，我照搬过来骂男性，这样我们就有挣不完的钱了！”——“对的，孺子可教，我们的想法，哪是那些凡夫俗子可以理解的。',
    '666我负责冒犯，观众负责艺术啊。现在都讲究线上线下结合，我负责在线上冒犯女性，观众在线下思考为什么是艺术”“可她们要是思考不出来，就光觉得被冒犯了呢？”——“你在说谁啊？谁觉得被冒犯了啊？”“观众啊？”——“什么观众？我又没冒犯观众。”“什么意思啊？你不是刚说了你是冒犯的艺术，你负责冒犯么？”——“你脑子有问题吧，我说的观众当然都是男观众了，女的消费能力还不如狗，谁把她们当观众啊。”“那你就不怕她们生气了抵制你、批评你、举报你',
    '444清华那位学姐的事做的真不地道。“——“哪位学姐，做了什么事？”“清华有个姑娘，学弟的包不小心扫到她屁股了，事儿还没调查清楚，她就要社会性死亡人家，后来看录像调查清楚了，说是要大家互相道歉，你说这算什么事儿啊。”——“女人嘛，都是那么普通，又那么自信的。““你怎么这么说话？“——“我怎么了，我不就说了句实话吗，我看你是对号入座，急了急了急了。石头砸小狗，谁叫谁小狗。““你能不能讲道理'
];
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label1 = null;
        _this.label2 = null;
        _this.show1 = null;
        _this.show2 = null;
        _this.btn1 = null;
        _this.btn2 = null;
        _this.index1 = 0;
        _this.index2 = 0;
        return _this;
    }
    NewClass.prototype.onLoad = function () {
        var _this = this;
        this.btn1.node.on('click', function () {
            _this.label1.string = list[_this.index1];
            _this.index1++;
            if (_this.index1 >= list.length)
                _this.index1 = 0;
        });
        this.btn2.node.on('click', function () {
            _this.label2.string = list[_this.index2];
            _this.index2++;
            if (_this.index2 >= list.length)
                _this.index2 = 0;
        });
    };
    NewClass.prototype.update = function (dt) {
        var sa = cc.Label._shareAtlas;
        if (sa) {
            cc.log('STORM cc ^_^ >> ', sa._x, sa._y);
            this.show1.string = String(sa._x);
            this.show2.string = String(sa._y);
        }
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label2", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show2", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn1", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn2", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9OZXdTY3JpcHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFNUUsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFFNUMsSUFBTSxJQUFJLEdBQUc7SUFDVCxzTUFBc007SUFDdE0sNktBQTZLO0lBQzdLLGdMQUFnTDtJQUNoTCxpTEFBaUw7SUFDakwsK0xBQStMO0lBQy9MLDBOQUEwTjtJQUMxTixxTUFBcU07Q0FDeE0sQ0FBQztBQUdGO0lBQXNDLDRCQUFZO0lBQWxEO1FBQUEscUVBNENDO1FBMUNHLFlBQU0sR0FBYSxJQUFJLENBQUM7UUFHeEIsWUFBTSxHQUFhLElBQUksQ0FBQztRQUd4QixXQUFLLEdBQWEsSUFBSSxDQUFDO1FBR3ZCLFdBQUssR0FBYSxJQUFJLENBQUM7UUFHdkIsVUFBSSxHQUFjLElBQUksQ0FBQztRQUd2QixVQUFJLEdBQWMsSUFBSSxDQUFDO1FBRXZCLFlBQU0sR0FBVyxDQUFDLENBQUM7UUFDbkIsWUFBTSxHQUFXLENBQUMsQ0FBQzs7SUF3QnZCLENBQUM7SUF0QkcseUJBQU0sR0FBTjtRQUFBLGlCQVlDO1FBWEcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRTtZQUN2QixLQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3ZDLEtBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNkLElBQUksS0FBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTTtnQkFBRSxLQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUU7WUFDdkIsS0FBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxLQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDZCxJQUFJLEtBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU07Z0JBQUUsS0FBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQseUJBQU0sR0FBTixVQUFPLEVBQUU7UUFDTCxJQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztRQUNoQyxJQUFJLEVBQUUsRUFBRTtZQUNKLEVBQUUsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3JDO0lBQ0wsQ0FBQztJQXpDRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOzRDQUNLO0lBR3hCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7NENBQ0s7SUFHeEI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzsyQ0FDSTtJQUd2QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOzJDQUNJO0lBR3ZCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7MENBQ0c7SUFHdkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzswQ0FDRztJQWpCTixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBNEM1QjtJQUFELGVBQUM7Q0E1Q0QsQUE0Q0MsQ0E1Q3FDLEVBQUUsQ0FBQyxTQUFTLEdBNENqRDtrQkE1Q29CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuY29uc3QgbGlzdCA9IFtcbiAgICAn6L+Z5omN5Y+r6IKJIOWkuSDppo3pgJrluLjmg4XlhrXkuIvvvIzpuqblvZPlirPnmoTmr4/np43oj5zlk4HlnKjph4/kuIrpg73mnInnm7jlr7nmmI7noa7nmoTopoHmsYLvvIzku6Xkv53or4Hml6DorrrkvZXml7bkvZXlnLDlh7rlk4HnmoTpo5/nianpg73og73otKjph4/otovkuo7kuIDoh7TjgILogIzov5nmrKHnvZHlj4vku6zkubDliLDnmoTogonlpLnppo3ph4znmoTogonlpJrlsJHkuI3kuIDvvIzlvojlj6/og73mmK/lm6DkuLrkvZzkuLrkuIDmrL7mlrDlk4HkuIrluILov4fkuo7ljIblv5nvvIzlubbmsqHog73liLblrprlh7rlkIjnkIbjgIHkuKXmoLznmoTmoIflh4bvvIzlr7zoh7TkvaDlnKjkuI3lkIznmoTpl6jlupfkubDnmoTlpLnogonppo3ogonph4/lrozlhajnnIvor6XlupfnmoToia/lv4PmiJblpIfppJDluIjlgoXku6znmoTlv4Pmg4XjgILmr4/kuKrpuKHlnZfnmoTlt67liKvkuI3kvJrlpKrlpKfmraTlkI7vvIzpuqblvZPlirPmkYblh7rkuobkuIDlia/igJzmnInkuovlpb3llYbph4/igJ3nmoTmgIHluqbvvIzlnKjlvq7ljZrkuIrooajnpLrogonppoXnmoTliIbph4/lj6/og73mnInmiYDlgY/lt64nLFxuICAgICc2NjY2Njbmspnmi4nphbHlkoznlarojITphbHvvIznu5nmsYnloKHljJblpobnmoTpg6jliIblsLHlrozmiJDkuobjgILkuI3ov4fov5nov5jkuI3lpJ/vvIzlkozkurrkuIDmoLfvvIzopoHmg7PorqnlroPmiJDkuLrlub/lkYrkuIrnmoTlpKfmmI7mmJ/vvIzov5jlvpfnlKhQ5Zu+6L2v5Lu257uZ5a6D576O6aKc77yM5Y675o6J6Z2i5YyF5LiK55qE5bCP5a2U77yM6K6p5a6D4oCc55qu6IKk57uG6IW75pyJ5YWJ5rO94oCd5omN6KGM44CC5ZCM5qC377yM6JyC6Jyc5LuO5p2+6aW85LiK57yT57yT5rWB5LiL5p2l55qE6ZWc5aS055yL6LW35p2l5b6I6K+x5Lq677yM5L2G55yf55qE6JyC6Jyc5Lya6KKr5p2+6aW85ZC45pS277yM55WZ5LiL5LiA56eN56We5Ly85bC/5bqK55qE5Y2w6L+577yM5Zug5q2k6IGq5piO55qE5pGE5b2x5biI5Lus5oOz5Yiw5LqG55So5LiN5Lya6KKr5ZC45pS255qE5py65rK55p2l5Luj5pu/6JyC6Jyc44CC6ICM5bm/5ZGK5Lit5ZWk6YWS5ZKM5rG9JyxcbiAgICAnNTU1NTXmnKzotKjkuIrmmK/mtLvlnKjlub/lkYrntKDmnZDkuK3nmoTlubvlvbHvvIzlj6ropoHotJ/otKPnvo7nvo7nmoTlsLHooYzkuobvvIzigJznvZHnu5zlpZTnjrDigJ3lsLHliKvmjIfmnJvkuoZ+5bCx5ou/5rGJ5aCh5p2l6K+077yM6KaB5YGa5Ye65bm/5ZGK5Lit6YKj5qC36aWx5ruh5oy65ouU55qE5rGJ5aCh5Y+v5LiN5a655piT44CC6aaW5YWI6KaB6YCJ5LiN566h5aW95ZCD5LiO5ZCm77yM6Iez5bCR5Lil6YeN6LaF5qih44CB5Y6a5a6e5YyA56ew55qE57KX5aSn6IKJ6aW877yM5YaN5LiT6Zeo5Yi35LiA5bGC5rK55LiK5Y676K6p5YW25pu05aSa5rGB44CB6Zeq5Lqu44CC54S25ZCO5pGG5aW955Sf6I+c5ZKM6KW/57qi5p+/55qE5L2N572u77yM5ou/54mZ562+5Zu65a6a5L2P77yM5YiG5biD5b+F6aG756ym5ZCI6buE6YeR5YiG5YmyfuacgOWQjueUqOWMluWmhuajiee7meWug+epv+S4quWGheWinumrmO+8jOWGjeaLv+mSiOeuoeWcqOWQiOmAgueahOS9jee9ruaMpOS4iicsXG4gICAgJzQ0NDQ05bm/5ZGK5Zu+5LiO6aOf54mp5b6I5LiA6Ie05bCx566X5piv57uP5bi46KKr572R5Y+L6LCD5L6D4oCc5bCB6Z2i5qy66K+I4oCd55qE5bq35biI5YKF5Lmf4oCc5rSX5b+D6Z2p6Z2i4oCd77yM5byA5LqG57q/5LiL6Z2i6aaG77yM5ZaK5Ye65Y+j5Y+35bCx5piv6KaB5oqK5YyF6KOF5LiK55qE57qi54On54mb6IKJ6Z2i56uv5Yiw5L2g6Z2i5YmN44CC6YKj5LmI5aaC5p6c6Laz5aSf5Yqq5Yqb77yM6Iqx5aSa54K56ZKx77yM5piv5LiN5piv5pyJ5LiA5aSp5oiR5Lus5bCx6IO95pyJ5py65Lya5ZCD5Yiw5bm/5ZGK5Lit6YKj56eN5Luk5Lq65Z6C5raO55qE576O6aOf5ZGi77yf5b6I5Y+v5oOc77yM562U5qGI5piv5LiN5aSq5Y+v6IO977yB6L+Z5qC355qE5beo5peg6Zy455yf55qE5a2Y5Zyo5ZCX77yf5bm/5ZGK5Lit55qE6YKj5Lqb576O6aOf6Jm954S255yL6LW35p2l5Luk5Lq65Z6C5raO5qyy5ru044CB6aOf5qyy5aSn5aKe77yM5L2G5b6I5aSa5YW25a6e5qC55pys5bCx5LiN5a2Y5ZyoJyxcbiAgICAnOTk55L2g6K+05aW55Li656S+5Lya55qE6L+b5q2l6LSh54yu5LqG5aSa5bCR44CC5oiR55qE5qKm5oOz5bCx5piv6KaB5oiQ5Li655S354mI55qE5ZKq6JKZ77yM6YCa6L+H6aqC5aWz5oCn6LWw5LiK5Lq655Sf5beF5bOw44CC4oCd4oCc5omA5Lul5piv5Li65LqG5oyj6ZKx77yf4oCd4oCU4oCU4oCc5bCP5LyZ5a2Q77yM5L2g55qE5oKf5oCn5b6I6auY5Zib77yB6KaB5LiN6KaB6Lef552A5oiR77yM5oiR5pyJ5Liq5a6e5Lmg55Sf5LiA5Liq5pyI5bel6LWE5LqU5LiH77yM5oiR55yL5L2g5qC56aqo5LiN6ZSZ77yM5piv5Liq5LiH5Lit5peg5LiA55qE57uD5q2m5aWH5omN44CC4oCd4oCc5aW95ZWK5aW95ZWK77yM5oKo55So6L+Z5LiA5aWX5Y676aqC5aWz5oCn77yM562J5oKo6aqC5a6M5LqG77yM5oiR54Wn5pCs6L+H5p2l6aqC55S35oCn77yM6L+Z5qC35oiR5Lus5bCx5pyJ5oyj5LiN5a6M55qE6ZKx5LqG77yB4oCd4oCU4oCU4oCc5a+555qE77yM5a265a2Q5Y+v5pWZ77yM5oiR5Lus55qE5oOz5rOV77yM5ZOq5piv6YKj5Lqb5Yeh5aSr5L+X5a2Q5Y+v5Lul55CG6Kej55qE44CCJyxcbiAgICAnNjY25oiR6LSf6LSj5YaS54qv77yM6KeC5LyX6LSf6LSj6Im65pyv5ZWK44CC546w5Zyo6YO96K6y56m257q/5LiK57q/5LiL57uT5ZCI77yM5oiR6LSf6LSj5Zyo57q/5LiK5YaS54qv5aWz5oCn77yM6KeC5LyX5Zyo57q/5LiL5oCd6ICD5Li65LuA5LmI5piv6Im65pyv4oCd4oCc5Y+v5aW55Lus6KaB5piv5oCd6ICD5LiN5Ye65p2l77yM5bCx5YWJ6KeJ5b6X6KKr5YaS54qv5LqG5ZGi77yf4oCd4oCU4oCU4oCc5L2g5Zyo6K+06LCB5ZWK77yf6LCB6KeJ5b6X6KKr5YaS54qv5LqG5ZWK77yf4oCd4oCc6KeC5LyX5ZWK77yf4oCd4oCU4oCU4oCc5LuA5LmI6KeC5LyX77yf5oiR5Y+I5rKh5YaS54qv6KeC5LyX44CC4oCd4oCc5LuA5LmI5oSP5oCd5ZWK77yf5L2g5LiN5piv5Yia6K+05LqG5L2g5piv5YaS54qv55qE6Im65pyv77yM5L2g6LSf6LSj5YaS54qv5LmI77yf4oCd4oCU4oCU4oCc5L2g6ISR5a2Q5pyJ6Zeu6aKY5ZCn77yM5oiR6K+055qE6KeC5LyX5b2T54S26YO95piv55S36KeC5LyX5LqG77yM5aWz55qE5raI6LS56IO95Yqb6L+Y5LiN5aaC54uX77yM6LCB5oqK5aW55Lus5b2T6KeC5LyX5ZWK44CC4oCd4oCc6YKj5L2g5bCx5LiN5oCV5aW55Lus55Sf5rCU5LqG5oq15Yi25L2g44CB5om56K+E5L2g44CB5Li+5oql5L2gJyxcbiAgICAnNDQ05riF5Y2O6YKj5L2N5a2m5aeQ55qE5LqL5YGa55qE55yf5LiN5Zyw6YGT44CC4oCc4oCU4oCU4oCc5ZOq5L2N5a2m5aeQ77yM5YGa5LqG5LuA5LmI5LqL77yf4oCd4oCc5riF5Y2O5pyJ5Liq5aeR5aiY77yM5a2m5byf55qE5YyF5LiN5bCP5b+D5omr5Yiw5aW55bGB6IKh5LqG77yM5LqL5YS/6L+Y5rKh6LCD5p+l5riF5qWa77yM5aW55bCx6KaB56S+5Lya5oCn5q275Lqh5Lq65a6277yM5ZCO5p2l55yL5b2V5YOP6LCD5p+l5riF5qWa5LqG77yM6K+05piv6KaB5aSn5a625LqS55u46YGT5q2J77yM5L2g6K+06L+Z566X5LuA5LmI5LqL5YS/5ZWK44CC4oCd4oCU4oCU4oCc5aWz5Lq65Zib77yM6YO95piv6YKj5LmI5pmu6YCa77yM5Y+I6YKj5LmI6Ieq5L+h55qE44CC4oCc4oCc5L2g5oCO5LmI6L+Z5LmI6K+06K+d77yf4oCc4oCU4oCU4oCc5oiR5oCO5LmI5LqG77yM5oiR5LiN5bCx6K+05LqG5Y+l5a6e6K+d5ZCX77yM5oiR55yL5L2g5piv5a+55Y+35YWl5bqn77yM5oCl5LqG5oCl5LqG5oCl5LqG44CC55+z5aS056C45bCP54uX77yM6LCB5Y+r6LCB5bCP54uX44CC4oCc4oCc5L2g6IO95LiN6IO96K6y6YGT55CGJ1xuXTtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ld0NsYXNzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgbGFiZWwxOiBjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgbGFiZWwyOiBjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgc2hvdzE6IGNjLkxhYmVsID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcbiAgICBzaG93MjogY2MuTGFiZWwgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkJ1dHRvbilcbiAgICBidG4xOiBjYy5CdXR0b24gPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkJ1dHRvbilcbiAgICBidG4yOiBjYy5CdXR0b24gPSBudWxsO1xuXG4gICAgaW5kZXgxOiBudW1iZXIgPSAwO1xuICAgIGluZGV4MjogbnVtYmVyID0gMDtcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5idG4xLm5vZGUub24oJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5sYWJlbDEuc3RyaW5nID0gbGlzdFt0aGlzLmluZGV4MV07XG4gICAgICAgICAgICB0aGlzLmluZGV4MSsrO1xuICAgICAgICAgICAgaWYgKHRoaXMuaW5kZXgxID49IGxpc3QubGVuZ3RoKSB0aGlzLmluZGV4MSA9IDA7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuYnRuMi5ub2RlLm9uKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMubGFiZWwyLnN0cmluZyA9IGxpc3RbdGhpcy5pbmRleDJdO1xuICAgICAgICAgICAgdGhpcy5pbmRleDIrKztcbiAgICAgICAgICAgIGlmICh0aGlzLmluZGV4MiA+PSBsaXN0Lmxlbmd0aCkgdGhpcy5pbmRleDIgPSAwO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICB1cGRhdGUoZHQpIHtcbiAgICAgICAgY29uc3Qgc2EgPSBjYy5MYWJlbC5fc2hhcmVBdGxhcztcbiAgICAgICAgaWYgKHNhKSB7XG4gICAgICAgICAgICBjYy5sb2coJ1NUT1JNIGNjIF5fXiA+PiAnLCBzYS5feCwgc2EuX3kpO1xuICAgICAgICAgICAgdGhpcy5zaG93MS5zdHJpbmcgPSBTdHJpbmcoc2EuX3gpO1xuICAgICAgICAgICAgdGhpcy5zaG93Mi5zdHJpbmcgPSBTdHJpbmcoc2EuX3kpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19
//------QC-SOURCE-SPLIT------
