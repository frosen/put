
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/NewScript');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/NewScript.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6db9a2dz5dHr7xYK6/2RtYC', 'NewScript');
// NewScript.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var list = [
    '这才叫肉 夹 馍通常情况下，麦当劳的每种菜品在量上都有相对明确的要求，以保证无论何时何地出品的食物都能质量趋于一致。而这次网友们买到的肉夹馍里的肉多少不一，很可能是因为作为一款新品上市过于匆忙，并没能制定出合理、严格的标准，导致你在不同的门店买的夹肉馍肉量完全看该店的良心或备餐师傅们的心情。每个鸡块的差别不会太大此后，麦当劳摆出了一副“有事好商量”的态度，在微博上表示肉馅的分量可能有所偏差',
    '666666沙拉酱和番茄酱，给汉堡化妆的部分就完成了。不过这还不够，和人一样，要想让它成为广告上的大明星，还得用P图软件给它美颜，去掉面包上的小孔，让它“皮肤细腻有光泽”才行。同样，蜂蜜从松饼上缓缓流下来的镜头看起来很诱人，但真的蜂蜜会被松饼吸收，留下一种神似尿床的印迹，因此聪明的摄影师们想到了用不会被吸收的机油来代替蜂蜜。而广告中啤酒和汽',
    '55555本质上是活在广告素材中的幻影，只要负责美美的就行了，“网络奔现”就别指望了~就拿汉堡来说，要做出广告中那样饱满挺拔的汉堡可不容易。首先要选不管好吃与否，至少严重超模、厚实匀称的粗大肉饼，再专门刷一层油上去让其更多汁、闪亮。然后摆好生菜和西红柿的位置，拿牙签固定住，分布必须符合黄金分割~最后用化妆棉给它穿个内增高，再拿针管在合适的位置挤上',
    '44444广告图与食物很一致就算是经常被网友调侃“封面欺诈”的康师傅也“洗心革面”，开了线下面馆，喊出口号就是要把包装上的红烧牛肉面端到你面前。那么如果足够努力，花多点钱，是不是有一天我们就能有机会吃到广告中那种令人垂涎的美食呢？很可惜，答案是不太可能！这样的巨无霸真的存在吗？广告中的那些美食虽然看起来令人垂涎欲滴、食欲大增，但很多其实根本就不存在',
    '999你说她为社会的进步贡献了多少。我的梦想就是要成为男版的咪蒙，通过骂女性走上人生巅峰。”“所以是为了挣钱？”——“小伙子，你的悟性很高嘛！要不要跟着我，我有个实习生一个月工资五万，我看你根骨不错，是个万中无一的练武奇才。”“好啊好啊，您用这一套去骂女性，等您骂完了，我照搬过来骂男性，这样我们就有挣不完的钱了！”——“对的，孺子可教，我们的想法，哪是那些凡夫俗子可以理解的。',
    '666我负责冒犯，观众负责艺术啊。现在都讲究线上线下结合，我负责在线上冒犯女性，观众在线下思考为什么是艺术”“可她们要是思考不出来，就光觉得被冒犯了呢？”——“你在说谁啊？谁觉得被冒犯了啊？”“观众啊？”——“什么观众？我又没冒犯观众。”“什么意思啊？你不是刚说了你是冒犯的艺术，你负责冒犯么？”——“你脑子有问题吧，我说的观众当然都是男观众了，女的消费能力还不如狗，谁把她们当观众啊。”“那你就不怕她们生气了抵制你、批评你、举报你',
    '444清华那位学姐的事做的真不地道。“——“哪位学姐，做了什么事？”“清华有个姑娘，学弟的包不小心扫到她屁股了，事儿还没调查清楚，她就要社会性死亡人家，后来看录像调查清楚了，说是要大家互相道歉，你说这算什么事儿啊。”——“女人嘛，都是那么普通，又那么自信的。““你怎么这么说话？“——“我怎么了，我不就说了句实话吗，我看你是对号入座，急了急了急了。石头砸小狗，谁叫谁小狗。““你能不能讲道理',
    '各位觉得这些人的言行想法是聪慧还是愚蠢？他们还会和路人辩论，振振有词，有些地方说的确实有些道理。这些人不是一个人，两个人，而是一个群体，可以称得上是"他们"了吧。也许你看了会不理解他们，嘲笑他们，但仔细想想，在某个时间阶段，或者某个大环境下，"我们"会不会也表现得像"他们"一样呢？你觉得事后"他们"会反思自己的行为么？',
    '如果"我们"也曾经做出过这样集体不理智的行为，事后"我们"是会反思自己，还是会说，那个时代就是那样的，亦或把所有问题都甩给一个或几个人？"我们"真的没有经历过这种事吗？其次，我写的这些东西并非为了批判谁，而且反思，批判是对别人，反思是对自己。评论区说我不要擅自代表他人这一点我是非常认可的。我说的"我们"包含我自己，但不包含在看的每一位读者。',
    '就好比，有部分人砸日本车、抢盐、把一切称赞外国的行为视为崇洋媚外……我自认也不是这些人，但这些现象和这些群体是客观存在的，看着"他们"我会想，也许在某些时候，我也像"他们"一样荒唐而不自知。同时，我想如果我生活在三体世界，出生在大低谷之后的时代，没体验过公元人亲眼见证地球与三体的科技代差，我可能也会像大多数人一样，认为人类必胜。',
    '如果我没有亲身经历过水滴团灭人类舰队给人类带来的绝望，也许我也会畏惧那个执掌着两个世界毁灭钥匙的罗辑，选择那个圣母一样的程心……哪怕我知道了逃跑是人类的唯一出路，也许我依然会选择整个人类在一起等待毁灭，而不是让少数精英、高层、有钱人……逃走……我，不代表任何人，但我知道，是有"我们"这个群体存在的，而且，"我们"哪怕错了，也未必会反思、悔改、认错……如果"我们"真的像伟人期许的那样，是时代的缔造者，是真正的英雄，也许"我们"应该意识到，"我"的言行，也是在影响改变着这个时代的，哪怕只是沧海一粟，萤火之光，每个人都承担着属于自己，属于这个时代的责任。时代的成功是"我们"的光荣，时代的某些错误，是要由造成这个错误的"我们"中的每一个"我"承担的，而不仅仅是某一个个体。',
    '————————以下为原文————————',
    '尽管我是那么的反感程心，但我还是想说一句冒天下之大不韪的话，也许《三体》中最渣的是"我们"。是"我们"被时代裹挟着，把叶文洁推到了墙角。是"我们"用石块处决了雷迪亚兹。是"我们"在基础物理被智子锁死的情况下，居然做着超越三体人的春秋大梦。是"我们"把"青铜时代号"和"蓝色空间号"视作叛徒。是"我们"把罗辑一次次的捧上神坛，推入地狱！是"我们"选出了程心！！！',
    '是啊，历史是由人民书写的，一切的荣耀都归功于人民。那么，差错呢？难道就推给一两个决定了人类历史走向的人么？没有叶文洁，三体人不会探测距离他们如此之近的星系么？没有ETO，三体人不会来侵略太阳系么？没有程心，一切都不会逝去，生命和文明就会取得胜利么？【“打倒反动学术权威叶哲泰！！”“打倒一切反动学术权威！！”“打倒一切反动学说！！”】',
    '【"得知消息后，恐惧压倒了一切，他决定牺牲叶文洁，保护自己。半个世纪后，历史学家们一致认为，1969年的这一事件是以后人类历史的一个转折点。"】【一路上很顺利，但一个多小时后还是有人认出了罗辑，于是车里的人一致要求他下车。罗辑争辩说自己已经输入信用点买了票，当然有权坐车。有一个头发花白的老者拿出两枚现在已经很不常见的现金硬币扔给了他，他还是被赶下了车。“面壁者，你背把铁锹干什么？”车开时有人从车窗探出头问。“为自己挖墓。”罗辑说，引起了车里的一阵哄笑。没人知道他说的是真话。】',
    '【漫长的使命已经最后完成，那最沉重的责任现在离开了他。以后，不管他在已经女性化的人类眼中是怎样的恶魔和怪物，人们都不得不承认，纵观文明史，他的胜利无人能及。】【人群瞬间寂静下来，人们抬头看着，那架可能烧死了几十人的穿梭机轰鸣着从停泊区升起，拖着白色的尾迹直上高空，然后转向东方。人们似乎不敢相信眼前发生的事。',
    '只过了十几秒钟，又一架穿梭机从停泊区起飞，这次距离他们更近，轰鸣、火光和热浪让人群由僵滞陷入极度的狂乱中。接下来，第三架，第四架……停泊区的穿梭机相继强行发射，',
    '团团烈焰中，焦黑的人体拖着烟火在空中横飞，停泊区变成了火葬场！】【“前面的，拦截它！撞死它！！”又是那个女人的声音，“啊！他们能达到逃逸速度，他们能逃掉！他们能活！！',
    '啊啊啊！！我要光速飞船！！拦住它呀！掐死里面的！！”】',
    '……读者们秉持着上帝视角，当然可以随意点评书中的人物和选择。但如果真的代入其中，我们真的会比"我们"做的更好吗？"我们"真的能逃避属于自己的那份责任，把一切都推给某个个体，这……难道不是渣吗？',
    '毛主席说："群众是真正的英雄！"只能享受胜利的果实，不能承受失败的酸楚，这算什么英雄呢？章北海、罗辑这些人类之光是"我们"孕育出来的，程心、伊文思同样是从"我们"中走出来的。',
    '站在上帝的视角，我们当然知道程心是错的，罗辑悟出的宇宙社会学是战胜三体人的理论基础，我们人类只有牺牲大多数，让少数人逃亡才得以延续文明的火种。',
    '但抛开全知的视角，"我们"能接受自己和自己的孩子成为"牺牲品"，让少数精英、资本家、权贵，飞向宇宙吗？"我们"抛弃罗辑这个掌握着两个世界命运之剑的老疯子，选择看起来人畜无害的身后程心，只为睡个安稳觉，让自己觉得过了今天还有明天，看起来有什么不对？',
    '"我们"为自己的选择付出了代价，最后"我们"只接受胜利喜悦，不承担失败的责任，"我们"真的不渣吗……通过这次疫情，现实中的一些"我们"与三体中的"我们"难道没有相似之处吗？',
    '疫情初期，人心惶惶，尽管只是少数，但不少人真的也视新冠为"武汉病毒"，排斥湖北的同胞。',
    '我们挺过来了，欧美在病毒面前败下阵来，又有多少人无视在经济、军事、科技、民生上的巨大差距，觉得我们已经赶欧超美了，容不下半点不同的声音，仿佛说国外好的地方就是崇洋媚外。',
    '面对钟南山教授这样的英雄，多少人在疫情的时候视他为救世主，又在他代言，为商品站台，支持中药的时候对他出言不逊……'
];
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label1 = null;
        _this.label2 = null;
        _this.show1 = null;
        _this.show2 = null;
        _this.btn1 = null;
        _this.btn2 = null;
        _this.index1 = 0;
        _this.index2 = 0;
        return _this;
    }
    NewClass.prototype.onLoad = function () {
        var _this = this;
        this.btn1.node.on('click', function () {
            _this.label1.string = list[_this.index1];
            _this.index1++;
            if (_this.index1 >= list.length)
                _this.index1 = 0;
        });
        this.btn2.node.on('click', function () {
            _this.label2.string = list[_this.index2];
            _this.index2++;
            if (_this.index2 >= list.length)
                _this.index2 = 0;
        });
    };
    NewClass.prototype.update = function (dt) {
        var sa = cc.Label._shareAtlas;
        if (sa) {
            cc.log('STORM cc ^_^ >> ', sa._x, sa._y, Object.keys(sa._fontDefDictionary._letterDefinitions).length);
            this.show1.string = String(sa._x);
            this.show2.string = String(sa._y);
        }
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label2", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show2", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn1", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn2", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9OZXdTY3JpcHQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFNUUsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFFNUMsSUFBTSxJQUFJLEdBQUc7SUFDVCxzTUFBc007SUFDdE0sNktBQTZLO0lBQzdLLGdMQUFnTDtJQUNoTCxpTEFBaUw7SUFDakwsK0xBQStMO0lBQy9MLDBOQUEwTjtJQUMxTixxTUFBcU07SUFDck0sa0tBQWtLO0lBQ2xLLDZLQUE2SztJQUM3Syx1S0FBdUs7SUFDdkssa1ZBQWtWO0lBQ2xWLHVCQUF1QjtJQUN2QixzTEFBc0w7SUFDdEwseUtBQXlLO0lBQ3pLLGtQQUFrUDtJQUNsUCw0SkFBNEo7SUFDNUosa0ZBQWtGO0lBQ2xGLHFGQUFxRjtJQUNyRiw2QkFBNkI7SUFDN0Isa0dBQWtHO0lBQ2xHLHlGQUF5RjtJQUN6Rix5RUFBeUU7SUFDekUsNkhBQTZIO0lBQzdILHdGQUF3RjtJQUN4Riw2Q0FBNkM7SUFDN0Msc0ZBQXNGO0lBQ3RGLDBEQUEwRDtDQUM3RCxDQUFDO0FBR0Y7SUFBc0MsNEJBQVk7SUFBbEQ7UUFBQSxxRUE0Q0M7UUExQ0csWUFBTSxHQUFhLElBQUksQ0FBQztRQUd4QixZQUFNLEdBQWEsSUFBSSxDQUFDO1FBR3hCLFdBQUssR0FBYSxJQUFJLENBQUM7UUFHdkIsV0FBSyxHQUFhLElBQUksQ0FBQztRQUd2QixVQUFJLEdBQWMsSUFBSSxDQUFDO1FBR3ZCLFVBQUksR0FBYyxJQUFJLENBQUM7UUFFdkIsWUFBTSxHQUFXLENBQUMsQ0FBQztRQUNuQixZQUFNLEdBQVcsQ0FBQyxDQUFDOztJQXdCdkIsQ0FBQztJQXRCRyx5QkFBTSxHQUFOO1FBQUEsaUJBWUM7UUFYRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFO1lBQ3ZCLEtBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdkMsS0FBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2QsSUFBSSxLQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNO2dCQUFFLEtBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3BELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRTtZQUN2QixLQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3ZDLEtBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNkLElBQUksS0FBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTTtnQkFBRSxLQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx5QkFBTSxHQUFOLFVBQU8sRUFBRTtRQUNMLElBQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO1FBQ2hDLElBQUksRUFBRSxFQUFFO1lBQ0osRUFBRSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsa0JBQWtCLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2RyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDckM7SUFDTCxDQUFDO0lBekNEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7NENBQ0s7SUFHeEI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQzs0Q0FDSztJQUd4QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOzJDQUNJO0lBR3ZCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7MkNBQ0k7SUFHdkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQzswQ0FDRztJQUd2QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzBDQUNHO0lBakJOLFFBQVE7UUFENUIsT0FBTztPQUNhLFFBQVEsQ0E0QzVCO0lBQUQsZUFBQztDQTVDRCxBQTRDQyxDQTVDcUMsRUFBRSxDQUFDLFNBQVMsR0E0Q2pEO2tCQTVDb0IsUUFBUSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcbi8vIExlYXJuIEF0dHJpYnV0ZTpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxuXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xuXG5jb25zdCBsaXN0ID0gW1xuICAgICfov5nmiY3lj6vogokg5aS5IOmmjemAmuW4uOaDheWGteS4i++8jOm6puW9k+WKs+eahOavj+enjeiPnOWTgeWcqOmHj+S4iumDveacieebuOWvueaYjuehrueahOimgeaxgu+8jOS7peS/neivgeaXoOiuuuS9leaXtuS9leWcsOWHuuWTgeeahOmjn+eJqemDveiDvei0qOmHj+i2i+S6juS4gOiHtOOAguiAjOi/measoee9keWPi+S7rOS5sOWIsOeahOiCieWkuemmjemHjOeahOiCieWkmuWwkeS4jeS4gO+8jOW+iOWPr+iDveaYr+WboOS4uuS9nOS4uuS4gOasvuaWsOWTgeS4iuW4gui/h+S6juWMhuW/me+8jOW5tuayoeiDveWItuWumuWHuuWQiOeQhuOAgeS4peagvOeahOagh+WHhu+8jOWvvOiHtOS9oOWcqOS4jeWQjOeahOmXqOW6l+S5sOeahOWkueiCiemmjeiCiemHj+WujOWFqOeci+ivpeW6l+eahOiJr+W/g+aIluWkh+mkkOW4iOWCheS7rOeahOW/g+aDheOAguavj+S4qum4oeWdl+eahOW3ruWIq+S4jeS8muWkquWkp+atpOWQju+8jOm6puW9k+WKs+aRhuWHuuS6huS4gOWJr+KAnOacieS6i+WlveWVhumHj+KAneeahOaAgeW6pu+8jOWcqOW+ruWNmuS4iuihqOekuuiCiemmheeahOWIhumHj+WPr+iDveacieaJgOWBj+W3ricsXG4gICAgJzY2NjY2NuaymeaLiemFseWSjOeVquiMhOmFse+8jOe7meaxieWgoeWMluWmhueahOmDqOWIhuWwseWujOaIkOS6huOAguS4jei/h+i/mei/mOS4jeWkn++8jOWSjOS6uuS4gOagt++8jOimgeaDs+iuqeWug+aIkOS4uuW5v+WRiuS4iueahOWkp+aYjuaYn++8jOi/mOW+l+eUqFDlm77ova/ku7bnu5nlroPnvo7popzvvIzljrvmjonpnaLljIXkuIrnmoTlsI/lrZTvvIzorqnlroPigJznmq7ogqTnu4bohbvmnInlhYnms73igJ3miY3ooYzjgILlkIzmoLfvvIzonILonJzku47mnb7ppbzkuIrnvJPnvJPmtYHkuIvmnaXnmoTplZzlpLTnnIvotbfmnaXlvojor7HkurrvvIzkvYbnnJ/nmoTonILonJzkvJrooqvmnb7ppbzlkLjmlLbvvIznlZnkuIvkuIDnp43npZ7kvLzlsL/luornmoTljbDov7nvvIzlm6DmraTogarmmI7nmoTmkYTlvbHluIjku6zmg7PliLDkuobnlKjkuI3kvJrooqvlkLjmlLbnmoTmnLrmsrnmnaXku6Pmm7/onILonJzjgILogIzlub/lkYrkuK3llaTphZLlkozmsb0nLFxuICAgICc1NTU1NeacrOi0qOS4iuaYr+a0u+WcqOW5v+WRiue0oOadkOS4reeahOW5u+W9se+8jOWPquimgei0n+i0o+e+jue+jueahOWwseihjOS6hu+8jOKAnOe9kee7nOWllOeOsOKAneWwseWIq+aMh+acm+S6hn7lsLHmi7/msYnloKHmnaXor7TvvIzopoHlgZrlh7rlub/lkYrkuK3pgqPmoLfppbHmu6HmjLrmi5TnmoTmsYnloKHlj6/kuI3lrrnmmJPjgILpppblhYjopoHpgInkuI3nrqHlpb3lkIPkuI7lkKbvvIzoh7PlsJHkuKXph43otoXmqKHjgIHljprlrp7ljIDnp7DnmoTnspflpKfogonppbzvvIzlho3kuJPpl6jliLfkuIDlsYLmsrnkuIrljrvorqnlhbbmm7TlpJrmsYHjgIHpl6rkuq7jgILnhLblkI7mkYblpb3nlJ/oj5zlkozopb/nuqLmn7/nmoTkvY3nva7vvIzmi7/niZnnrb7lm7rlrprkvY/vvIzliIbluIPlv4XpobvnrKblkIjpu4Tph5HliIblibJ+5pyA5ZCO55So5YyW5aaG5qOJ57uZ5a6D56m/5Liq5YaF5aKe6auY77yM5YaN5ou/6ZKI566h5Zyo5ZCI6YCC55qE5L2N572u5oyk5LiKJyxcbiAgICAnNDQ0NDTlub/lkYrlm77kuI7po5/nianlvojkuIDoh7TlsLHnrpfmmK/nu4/luLjooqvnvZHlj4vosIPkvoPigJzlsIHpnaLmrLror4jigJ3nmoTlurfluIjlgoXkuZ/igJzmtJflv4PpnanpnaLigJ3vvIzlvIDkuobnur/kuIvpnaLppobvvIzllorlh7rlj6Plj7flsLHmmK/opoHmiorljIXoo4XkuIrnmoTnuqLng6fniZvogonpnaLnq6/liLDkvaDpnaLliY3jgILpgqPkuYjlpoLmnpzotrPlpJ/liqrlipvvvIzoirHlpJrngrnpkrHvvIzmmK/kuI3mmK/mnInkuIDlpKnmiJHku6zlsLHog73mnInmnLrkvJrlkIPliLDlub/lkYrkuK3pgqPnp43ku6TkurrlnoLmto7nmoTnvo7po5/lkaLvvJ/lvojlj6/mg5zvvIznrZTmoYjmmK/kuI3lpKrlj6/og73vvIHov5nmoLfnmoTlt6jml6DpnLjnnJ/nmoTlrZjlnKjlkJfvvJ/lub/lkYrkuK3nmoTpgqPkupvnvo7po5/omb3nhLbnnIvotbfmnaXku6TkurrlnoLmto7mrLLmu7TjgIHpo5/mrLLlpKflop7vvIzkvYblvojlpJrlhbblrp7moLnmnKzlsLHkuI3lrZjlnKgnLFxuICAgICc5OTnkvaDor7TlpbnkuLrnpL7kvJrnmoTov5vmraXotKHnjK7kuoblpJrlsJHjgILmiJHnmoTmoqbmg7PlsLHmmK/opoHmiJDkuLrnlLfniYjnmoTlkqrokpnvvIzpgJrov4fpqoLlpbPmgKfotbDkuIrkurrnlJ/lt4Xls7DjgILigJ3igJzmiYDku6XmmK/kuLrkuobmjKPpkrHvvJ/igJ3igJTigJTigJzlsI/kvJnlrZDvvIzkvaDnmoTmgp/mgKflvojpq5jlmJvvvIHopoHkuI3opoHot5/nnYDmiJHvvIzmiJHmnInkuKrlrp7kuaDnlJ/kuIDkuKrmnIjlt6XotYTkupTkuIfvvIzmiJHnnIvkvaDmoLnpqqjkuI3plJnvvIzmmK/kuKrkuIfkuK3ml6DkuIDnmoTnu4PmrablpYfmiY3jgILigJ3igJzlpb3llYrlpb3llYrvvIzmgqjnlKjov5nkuIDlpZfljrvpqoLlpbPmgKfvvIznrYnmgqjpqoLlrozkuobvvIzmiJHnhafmkKzov4fmnaXpqoLnlLfmgKfvvIzov5nmoLfmiJHku6zlsLHmnInmjKPkuI3lroznmoTpkrHkuobvvIHigJ3igJTigJTigJzlr7nnmoTvvIzlrbrlrZDlj6/mlZnvvIzmiJHku6znmoTmg7Pms5XvvIzlk6rmmK/pgqPkupvlh6HlpKvkv5flrZDlj6/ku6XnkIbop6PnmoTjgIInLFxuICAgICc2NjbmiJHotJ/otKPlhpLniq/vvIzop4LkvJfotJ/otKPoibrmnK/llYrjgILnjrDlnKjpg73orrLnqbbnur/kuIrnur/kuIvnu5PlkIjvvIzmiJHotJ/otKPlnKjnur/kuIrlhpLniq/lpbPmgKfvvIzop4LkvJflnKjnur/kuIvmgJ3ogIPkuLrku4DkuYjmmK/oibrmnK/igJ3igJzlj6/lpbnku6zopoHmmK/mgJ3ogIPkuI3lh7rmnaXvvIzlsLHlhYnop4nlvpfooqvlhpLniq/kuoblkaLvvJ/igJ3igJTigJTigJzkvaDlnKjor7TosIHllYrvvJ/osIHop4nlvpfooqvlhpLniq/kuobllYrvvJ/igJ3igJzop4LkvJfllYrvvJ/igJ3igJTigJTigJzku4DkuYjop4LkvJfvvJ/miJHlj4jmsqHlhpLniq/op4LkvJfjgILigJ3igJzku4DkuYjmhI/mgJ3llYrvvJ/kvaDkuI3mmK/liJror7TkuobkvaDmmK/lhpLniq/nmoToibrmnK/vvIzkvaDotJ/otKPlhpLniq/kuYjvvJ/igJ3igJTigJTigJzkvaDohJHlrZDmnInpl67popjlkKfvvIzmiJHor7TnmoTop4LkvJflvZPnhLbpg73mmK/nlLfop4LkvJfkuobvvIzlpbPnmoTmtojotLnog73lipvov5jkuI3lpoLni5fvvIzosIHmiorlpbnku6zlvZPop4LkvJfllYrjgILigJ3igJzpgqPkvaDlsLHkuI3mgJXlpbnku6znlJ/msJTkuobmirXliLbkvaDjgIHmibnor4TkvaDjgIHkuL7miqXkvaAnLFxuICAgICc0NDTmuIXljY7pgqPkvY3lrablp5DnmoTkuovlgZrnmoTnnJ/kuI3lnLDpgZPjgILigJzigJTigJTigJzlk6rkvY3lrablp5DvvIzlgZrkuobku4DkuYjkuovvvJ/igJ3igJzmuIXljY7mnInkuKrlp5HlqJjvvIzlrablvJ/nmoTljIXkuI3lsI/lv4PmiavliLDlpbnlsYHogqHkuobvvIzkuovlhL/ov5jmsqHosIPmn6XmuIXmpZrvvIzlpbnlsLHopoHnpL7kvJrmgKfmrbvkuqHkurrlrrbvvIzlkI7mnaXnnIvlvZXlg4/osIPmn6XmuIXmpZrkuobvvIzor7TmmK/opoHlpKflrrbkupLnm7jpgZPmrYnvvIzkvaDor7Tov5nnrpfku4DkuYjkuovlhL/llYrjgILigJ3igJTigJTigJzlpbPkurrlmJvvvIzpg73mmK/pgqPkuYjmma7pgJrvvIzlj4jpgqPkuYjoh6rkv6HnmoTjgILigJzigJzkvaDmgI7kuYjov5nkuYjor7Tor53vvJ/igJzigJTigJTigJzmiJHmgI7kuYjkuobvvIzmiJHkuI3lsLHor7Tkuoblj6Xlrp7or53lkJfvvIzmiJHnnIvkvaDmmK/lr7nlj7flhaXluqfvvIzmgKXkuobmgKXkuobmgKXkuobjgILnn7PlpLTnoLjlsI/ni5fvvIzosIHlj6vosIHlsI/ni5fjgILigJzigJzkvaDog73kuI3og73orrLpgZPnkIYnLFxuICAgICflkITkvY3op4nlvpfov5nkupvkurrnmoToqIDooYzmg7Pms5XmmK/ogarmhafov5jmmK/mhJrooKLvvJ/ku5bku6zov5jkvJrlkozot6/kurrovqnorrrvvIzmjK/mjK/mnInor43vvIzmnInkupvlnLDmlrnor7TnmoTnoa7lrp7mnInkupvpgZPnkIbjgILov5nkupvkurrkuI3mmK/kuIDkuKrkurrvvIzkuKTkuKrkurrvvIzogIzmmK/kuIDkuKrnvqTkvZPvvIzlj6/ku6Xnp7DlvpfkuIrmmK9cIuS7luS7rFwi5LqG5ZCn44CC5Lmf6K645L2g55yL5LqG5Lya5LiN55CG6Kej5LuW5Lus77yM5Ziy56yR5LuW5Lus77yM5L2G5LuU57uG5oOz5oOz77yM5Zyo5p+Q5Liq5pe26Ze06Zi25q6177yM5oiW6ICF5p+Q5Liq5aSn546v5aKD5LiL77yMXCLmiJHku6xcIuS8muS4jeS8muS5n+ihqOeOsOW+l+WDj1wi5LuW5LusXCLkuIDmoLflkaLvvJ/kvaDop4nlvpfkuovlkI5cIuS7luS7rFwi5Lya5Y+N5oCd6Ieq5bex55qE6KGM5Li65LmI77yfJyxcbiAgICAn5aaC5p6cXCLmiJHku6xcIuS5n+abvue7j+WBmuWHuui/h+i/meagt+mbhuS9k+S4jeeQhuaZuueahOihjOS4uu+8jOS6i+WQjlwi5oiR5LusXCLmmK/kvJrlj43mgJ3oh6rlt7HvvIzov5jmmK/kvJror7TvvIzpgqPkuKrml7bku6PlsLHmmK/pgqPmoLfnmoTvvIzkuqbmiJbmiormiYDmnInpl67popjpg73nlKnnu5nkuIDkuKrmiJblh6DkuKrkurrvvJ9cIuaIkeS7rFwi55yf55qE5rKh5pyJ57uP5Y6G6L+H6L+Z56eN5LqL5ZCX77yf5YW25qyh77yM5oiR5YaZ55qE6L+Z5Lqb5Lic6KW/5bm26Z2e5Li65LqG5om55Yik6LCB77yM6ICM5LiU5Y+N5oCd77yM5om55Yik5piv5a+55Yir5Lq677yM5Y+N5oCd5piv5a+56Ieq5bex44CC6K+E6K665Yy66K+05oiR5LiN6KaB5pOF6Ieq5Luj6KGo5LuW5Lq66L+Z5LiA54K55oiR5piv6Z2e5bi46K6k5Y+v55qE44CC5oiR6K+055qEXCLmiJHku6xcIuWMheWQq+aIkeiHquW3se+8jOS9huS4jeWMheWQq+WcqOeci+eahOavj+S4gOS9jeivu+iAheOAgicsXG4gICAgJ+WwseWlveavlO+8jOaciemDqOWIhuS6uueguOaXpeacrOi9puOAgeaKouebkOOAgeaKiuS4gOWIh+ensOi1nuWkluWbveeahOihjOS4uuinhuS4uuW0h+a0i+WqmuWkluKApuKApuaIkeiHquiupOS5n+S4jeaYr+i/meS6m+S6uu+8jOS9hui/meS6m+eOsOixoeWSjOi/meS6m+e+pOS9k+aYr+WuouinguWtmOWcqOeahO+8jOeci+edgFwi5LuW5LusXCLmiJHkvJrmg7PvvIzkuZ/orrjlnKjmn5Dkupvml7blgJnvvIzmiJHkuZ/lg49cIuS7luS7rFwi5LiA5qC36I2S5ZSQ6ICM5LiN6Ieq55+l44CC5ZCM5pe277yM5oiR5oOz5aaC5p6c5oiR55Sf5rS75Zyo5LiJ5L2T5LiW55WM77yM5Ye655Sf5Zyo5aSn5L2O6LC35LmL5ZCO55qE5pe25Luj77yM5rKh5L2T6aqM6L+H5YWs5YWD5Lq65Lqy55y86KeB6K+B5Zyw55CD5LiO5LiJ5L2T55qE56eR5oqA5Luj5beu77yM5oiR5Y+v6IO95Lmf5Lya5YOP5aSn5aSa5pWw5Lq65LiA5qC377yM6K6k5Li65Lq657G75b+F6IOc44CCJyxcbiAgICAn5aaC5p6c5oiR5rKh5pyJ5Lqy6Lqr57uP5Y6G6L+H5rC05ru05Zui54Gt5Lq657G76Iiw6Zif57uZ5Lq657G75bim5p2l55qE57ud5pyb77yM5Lmf6K645oiR5Lmf5Lya55WP5oOn6YKj5Liq5omn5o6M552A5Lik5Liq5LiW55WM5q+B54Gt6ZKl5YyZ55qE572X6L6R77yM6YCJ5oup6YKj5Liq5Zyj5q+N5LiA5qC355qE56iL5b+D4oCm4oCm5ZOq5oCV5oiR55+l6YGT5LqG6YCD6LeR5piv5Lq657G755qE5ZSv5LiA5Ye66Lev77yM5Lmf6K645oiR5L6d54S25Lya6YCJ5oup5pW05Liq5Lq657G75Zyo5LiA6LW3562J5b6F5q+B54Gt77yM6ICM5LiN5piv6K6p5bCR5pWw57K+6Iux44CB6auY5bGC44CB5pyJ6ZKx5Lq64oCm4oCm6YCD6LWw4oCm4oCm5oiR77yM5LiN5Luj6KGo5Lu75L2V5Lq677yM5L2G5oiR55+l6YGT77yM5piv5pyJXCLmiJHku6xcIui/meS4que+pOS9k+WtmOWcqOeahO+8jOiAjOS4lO+8jFwi5oiR5LusXCLlk6rmgJXplJnkuobvvIzkuZ/mnKrlv4XkvJrlj43mgJ3jgIHmgpTmlLnjgIHorqTplJnigKbigKblpoLmnpxcIuaIkeS7rFwi55yf55qE5YOP5Lyf5Lq65pyf6K6455qE6YKj5qC377yM5piv5pe25Luj55qE57yU6YCg6ICF77yM5piv55yf5q2j55qE6Iux6ZuE77yM5Lmf6K64XCLmiJHku6xcIuW6lOivpeaEj+ivhuWIsO+8jFwi5oiRXCLnmoToqIDooYzvvIzkuZ/mmK/lnKjlvbHlk43mlLnlj5jnnYDov5nkuKrml7bku6PnmoTvvIzlk6rmgJXlj6rmmK/msqfmtbfkuIDnsp/vvIzokKTngavkuYvlhYnvvIzmr4/kuKrkurrpg73mib/mi4XnnYDlsZ7kuo7oh6rlt7HvvIzlsZ7kuo7ov5nkuKrml7bku6PnmoTotKPku7vjgILml7bku6PnmoTmiJDlip/mmK9cIuaIkeS7rFwi55qE5YWJ6I2j77yM5pe25Luj55qE5p+Q5Lqb6ZSZ6K+v77yM5piv6KaB55Sx6YCg5oiQ6L+Z5Liq6ZSZ6K+v55qEXCLmiJHku6xcIuS4reeahOavj+S4gOS4qlwi5oiRXCLmib/mi4XnmoTvvIzogIzkuI3ku4Xku4XmmK/mn5DkuIDkuKrkuKrkvZPjgIInLFxuICAgICfigJTigJTigJTigJTigJTigJTigJTigJTku6XkuIvkuLrljp/mlofigJTigJTigJTigJTigJTigJTigJTigJQnLFxuICAgICflsL3nrqHmiJHmmK/pgqPkuYjnmoTlj43mhJ/nqIvlv4PvvIzkvYbmiJHov5jmmK/mg7Por7TkuIDlj6XlhpLlpKnkuIvkuYvlpKfkuI3pn6rnmoTor53vvIzkuZ/orrjjgIrkuInkvZPjgIvkuK3mnIDmuKPnmoTmmK9cIuaIkeS7rFwi44CC5pivXCLmiJHku6xcIuiiq+aXtuS7o+ijueaMn+edgO+8jOaKiuWPtuaWh+a0geaOqOWIsOS6huWimeinkuOAguaYr1wi5oiR5LusXCLnlKjnn7PlnZflpITlhrPkuobpm7fov6rkuprlhbnjgILmmK9cIuaIkeS7rFwi5Zyo5Z+656GA54mp55CG6KKr5pm65a2Q6ZSB5q2755qE5oOF5Ya15LiL77yM5bGF54S25YGa552A6LaF6LaK5LiJ5L2T5Lq655qE5pil56eL5aSn5qKm44CC5pivXCLmiJHku6xcIuaKilwi6Z2S6ZOc5pe25Luj5Y+3XCLlkoxcIuiTneiJsuepuumXtOWPt1wi6KeG5L2c5Y+b5b6S44CC5pivXCLmiJHku6xcIuaKiue9l+i+keS4gOasoeasoeeahOaNp+S4iuelnuWdm++8jOaOqOWFpeWcsOeLse+8geaYr1wi5oiR5LusXCLpgInlh7rkuobnqIvlv4PvvIHvvIHvvIEnLFxuICAgICfmmK/llYrvvIzljoblj7LmmK/nlLHkurrmsJHkuablhpnnmoTvvIzkuIDliIfnmoTojaPogIDpg73lvZLlip/kuo7kurrmsJHjgILpgqPkuYjvvIzlt67plJnlkaLvvJ/pmr7pgZPlsLHmjqjnu5nkuIDkuKTkuKrlhrPlrprkuobkurrnsbvljoblj7LotbDlkJHnmoTkurrkuYjvvJ/msqHmnInlj7bmlofmtIHvvIzkuInkvZPkurrkuI3kvJrmjqLmtYvot53nprvku5bku6zlpoLmraTkuYvov5HnmoTmmJ/ns7vkuYjvvJ/msqHmnIlFVE/vvIzkuInkvZPkurrkuI3kvJrmnaXkvrXnlaXlpKrpmLPns7vkuYjvvJ/msqHmnInnqIvlv4PvvIzkuIDliIfpg73kuI3kvJrpgJ3ljrvvvIznlJ/lkb3lkozmlofmmI7lsLHkvJrlj5blvpfog5zliKnkuYjvvJ/jgJDigJzmiZPlgJLlj43liqjlrabmnK/mnYPlqIHlj7blk7Lms7DvvIHvvIHigJ3igJzmiZPlgJLkuIDliIflj43liqjlrabmnK/mnYPlqIHvvIHvvIHigJ3igJzmiZPlgJLkuIDliIflj43liqjlrabor7TvvIHvvIHigJ3jgJEnLFxuICAgICfjgJBcIuW+l+efpea2iOaBr+WQju+8jOaBkOaDp+WOi+WAkuS6huS4gOWIh++8jOS7luWGs+WumueJuueJsuWPtuaWh+a0ge+8jOS/neaKpOiHquW3seOAguWNiuS4quS4lue6quWQju+8jOWOhuWPsuWtpuWutuS7rOS4gOiHtOiupOS4uu+8jDE5NjnlubTnmoTov5nkuIDkuovku7bmmK/ku6XlkI7kurrnsbvljoblj7LnmoTkuIDkuKrovazmipjngrnjgIJcIuOAkeOAkOS4gOi3r+S4iuW+iOmhuuWIqe+8jOS9huS4gOS4quWkmuWwj+aXtuWQjui/mOaYr+acieS6uuiupOWHuuS6hue9l+i+ke+8jOS6juaYr+i9pumHjOeahOS6uuS4gOiHtOimgeaxguS7luS4i+i9puOAgue9l+i+keS6iei+qeivtOiHquW3seW3sue7j+i+k+WFpeS/oeeUqOeCueS5sOS6huelqO+8jOW9k+eEtuacieadg+WdkOi9puOAguacieS4gOS4quWktOWPkeiKseeZveeahOiAgeiAheaLv+WHuuS4pOaemueOsOWcqOW3sue7j+W+iOS4jeW4uOingeeahOeOsOmHkeehrOW4geaJlOe7meS6huS7lu+8jOS7lui/mOaYr+iiq+i1tuS4i+S6hui9puOAguKAnOmdouWjgeiAhe+8jOS9oOiDjOaKiumTgemUueW5suS7gOS5iO+8n+KAnei9puW8gOaXtuacieS6uuS7jui9pueql+aOouWHuuWktOmXruOAguKAnOS4uuiHquW3seaMluWik+OAguKAnee9l+i+keivtO+8jOW8lei1t+S6hui9pumHjOeahOS4gOmYteWThOeskeOAguayoeS6uuefpemBk+S7luivtOeahOaYr+ecn+ivneOAguOAkScsXG4gICAgJ+OAkOa8q+mVv+eahOS9v+WRveW3sue7j+acgOWQjuWujOaIkO+8jOmCo+acgOayiemHjeeahOi0o+S7u+eOsOWcqOemu+W8gOS6huS7luOAguS7peWQju+8jOS4jeeuoeS7luWcqOW3sue7j+Wls+aAp+WMlueahOS6uuexu+ecvOS4reaYr+aAjuagt+eahOaBtumtlOWSjOaAqueJqe+8jOS6uuS7rOmDveS4jeW+l+S4jeaJv+iupO+8jOe6teinguaWh+aYjuWPsu+8jOS7lueahOiDnOWIqeaXoOS6uuiDveWPiuOAguOAkeOAkOS6uue+pOeerOmXtOWvgumdmeS4i+adpe+8jOS6uuS7rOaKrOWktOeci+edgO+8jOmCo+aetuWPr+iDveeDp+atu+S6huWHoOWNgeS6uueahOepv+aireacuui9sOm4o+edgOS7juWBnOaziuWMuuWNh+i1t++8jOaLluedgOeZveiJsueahOWwvui/ueebtOS4iumrmOepuu+8jOeEtuWQjui9rOWQkeS4nOaWueOAguS6uuS7rOS8vOS5juS4jeaVouebuOS/oeecvOWJjeWPkeeUn+eahOS6i+OAgicsXG4gICAgJ+WPqui/h+S6huWNgeWHoOenkumSn++8jOWPiOS4gOaetuepv+aireacuuS7juWBnOaziuWMuui1t+mjnu+8jOi/measoei3neemu+S7luS7rOabtOi/ke+8jOi9sOm4o+OAgeeBq+WFieWSjOeDrea1quiuqeS6uue+pOeUseWDtea7numZt+WFpeaegeW6pueahOeLguS5seS4reOAguaOpeS4i+adpe+8jOesrOS4ieaetu+8jOesrOWbm+aetuKApuKApuWBnOaziuWMuueahOepv+aireacuuebuOe7p+W8uuihjOWPkeWwhO+8jCcsXG4gICAgJ+WbouWboueDiOeEsOS4re+8jOeEpum7keeahOS6uuS9k+aLluedgOeDn+eBq+WcqOepuuS4reaoqumjnu+8jOWBnOaziuWMuuWPmOaIkOS6hueBq+iRrOWcuu+8geOAkeOAkOKAnOWJjemdoueahO+8jOaLpuaIquWug++8geaSnuatu+Wug++8ge+8geKAneWPiOaYr+mCo+S4quWls+S6uueahOWjsOmfs++8jOKAnOWViu+8geS7luS7rOiDvei+vuWIsOmAg+mAuOmAn+W6pu+8jOS7luS7rOiDvemAg+aOie+8geS7luS7rOiDvea0u++8ge+8gScsXG4gICAgJ+WViuWViuWViu+8ge+8geaIkeimgeWFiemAn+mjnuiIue+8ge+8geaLpuS9j+Wug+WRgO+8geaOkOatu+mHjOmdoueahO+8ge+8geKAneOAkScsXG4gICAgJ+KApuKApuivu+iAheS7rOenieaMgeedgOS4iuW4neinhuinku+8jOW9k+eEtuWPr+S7pemaj+aEj+eCueivhOS5puS4reeahOS6uueJqeWSjOmAieaLqeOAguS9huWmguaenOecn+eahOS7o+WFpeWFtuS4re+8jOaIkeS7rOecn+eahOS8muavlFwi5oiR5LusXCLlgZrnmoTmm7Tlpb3lkJfvvJ9cIuaIkeS7rFwi55yf55qE6IO96YCD6YG/5bGe5LqO6Ieq5bex55qE6YKj5Lu96LSj5Lu777yM5oqK5LiA5YiH6YO95o6o57uZ5p+Q5Liq5Liq5L2T77yM6L+Z4oCm4oCm6Zq+6YGT5LiN5piv5rij5ZCX77yfJyxcbiAgICAn5q+b5Li75bit6K+077yaXCLnvqTkvJfmmK/nnJ/mraPnmoToi7Hpm4TvvIFcIuWPquiDveS6q+WPl+iDnOWIqeeahOaenOWunu+8jOS4jeiDveaJv+WPl+Wksei0peeahOmFuOalmu+8jOi/meeul+S7gOS5iOiLsembhOWRou+8n+eroOWMl+a1t+OAgee9l+i+kei/meS6m+S6uuexu+S5i+WFieaYr1wi5oiR5LusXCLlrZXogrLlh7rmnaXnmoTvvIznqIvlv4PjgIHkvIrmlofmgJ3lkIzmoLfmmK/ku45cIuaIkeS7rFwi5Lit6LWw5Ye65p2l55qE44CCJyxcbiAgICAn56uZ5Zyo5LiK5bid55qE6KeG6KeS77yM5oiR5Lus5b2T54S255+l6YGT56iL5b+D5piv6ZSZ55qE77yM572X6L6R5oKf5Ye655qE5a6H5a6Z56S+5Lya5a2m5piv5oiY6IOc5LiJ5L2T5Lq655qE55CG6K665Z+656GA77yM5oiR5Lus5Lq657G75Y+q5pyJ54m654my5aSn5aSa5pWw77yM6K6p5bCR5pWw5Lq66YCD5Lqh5omN5b6X5Lul5bu257ut5paH5piO55qE54Gr56eN44CCJyxcbiAgICAn5L2G5oqb5byA5YWo55+l55qE6KeG6KeS77yMXCLmiJHku6xcIuiDveaOpeWPl+iHquW3seWSjOiHquW3seeahOWtqeWtkOaIkOS4ulwi54m654my5ZOBXCLvvIzorqnlsJHmlbDnsr7oi7HjgIHotYTmnKzlrrbjgIHmnYPotLXvvIzpo57lkJHlroflrpnlkJfvvJ9cIuaIkeS7rFwi5oqb5byD572X6L6R6L+Z5Liq5o6M5o+h552A5Lik5Liq5LiW55WM5ZG96L+Q5LmL5YmR55qE6ICB55av5a2Q77yM6YCJ5oup55yL6LW35p2l5Lq655Wc5peg5a6z55qE6Lqr5ZCO56iL5b+D77yM5Y+q5Li6552h5Liq5a6J56iz6KeJ77yM6K6p6Ieq5bex6KeJ5b6X6L+H5LqG5LuK5aSp6L+Y5pyJ5piO5aSp77yM55yL6LW35p2l5pyJ5LuA5LmI5LiN5a+577yfJyxcbiAgICAnXCLmiJHku6xcIuS4uuiHquW3seeahOmAieaLqeS7mOWHuuS6huS7o+S7t++8jOacgOWQjlwi5oiR5LusXCLlj6rmjqXlj5fog5zliKnllpzmgqbvvIzkuI3mib/mi4XlpLHotKXnmoTotKPku7vvvIxcIuaIkeS7rFwi55yf55qE5LiN5rij5ZCX4oCm4oCm6YCa6L+H6L+Z5qyh55ar5oOF77yM546w5a6e5Lit55qE5LiA5LqbXCLmiJHku6xcIuS4juS4ieS9k+S4reeahFwi5oiR5LusXCLpmr7pgZPmsqHmnInnm7jkvLzkuYvlpITlkJfvvJ8nLFxuICAgICfnlqvmg4XliJ3mnJ/vvIzkurrlv4Pmg7bmg7bvvIzlsL3nrqHlj6rmmK/lsJHmlbDvvIzkvYbkuI3lsJHkurrnnJ/nmoTkuZ/op4bmlrDlhqDkuLpcIuatpuaxieeXheavklwi77yM5o6S5pal5rmW5YyX55qE5ZCM6IOe44CCJyxcbiAgICAn5oiR5Lus5oy66L+H5p2l5LqG77yM5qyn576O5Zyo55eF5q+S6Z2i5YmN6LSl5LiL6Zi15p2l77yM5Y+I5pyJ5aSa5bCR5Lq65peg6KeG5Zyo57uP5rWO44CB5Yab5LqL44CB56eR5oqA44CB5rCR55Sf5LiK55qE5beo5aSn5beu6Led77yM6KeJ5b6X5oiR5Lus5bey57uP6LW25qyn6LaF576O5LqG77yM5a655LiN5LiL5Y2K54K55LiN5ZCM55qE5aOw6Z+z77yM5Lu/5L2b6K+05Zu95aSW5aW955qE5Zyw5pa55bCx5piv5bSH5rSL5aqa5aSW44CCJyxcbiAgICAn6Z2i5a+56ZKf5Y2X5bGx5pWZ5o6I6L+Z5qC355qE6Iux6ZuE77yM5aSa5bCR5Lq65Zyo55ar5oOF55qE5pe25YCZ6KeG5LuW5Li65pWR5LiW5Li777yM5Y+I5Zyo5LuW5Luj6KiA77yM5Li65ZWG5ZOB56uZ5Y+w77yM5pSv5oyB5Lit6I2v55qE5pe25YCZ5a+55LuW5Ye66KiA5LiN6YCK4oCm4oCmJ1xuXTtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE5ld0NsYXNzIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgbGFiZWwxOiBjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgbGFiZWwyOiBjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgc2hvdzE6IGNjLkxhYmVsID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcbiAgICBzaG93MjogY2MuTGFiZWwgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkJ1dHRvbilcbiAgICBidG4xOiBjYy5CdXR0b24gPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkJ1dHRvbilcbiAgICBidG4yOiBjYy5CdXR0b24gPSBudWxsO1xuXG4gICAgaW5kZXgxOiBudW1iZXIgPSAwO1xuICAgIGluZGV4MjogbnVtYmVyID0gMDtcblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5idG4xLm5vZGUub24oJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5sYWJlbDEuc3RyaW5nID0gbGlzdFt0aGlzLmluZGV4MV07XG4gICAgICAgICAgICB0aGlzLmluZGV4MSsrO1xuICAgICAgICAgICAgaWYgKHRoaXMuaW5kZXgxID49IGxpc3QubGVuZ3RoKSB0aGlzLmluZGV4MSA9IDA7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuYnRuMi5ub2RlLm9uKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMubGFiZWwyLnN0cmluZyA9IGxpc3RbdGhpcy5pbmRleDJdO1xuICAgICAgICAgICAgdGhpcy5pbmRleDIrKztcbiAgICAgICAgICAgIGlmICh0aGlzLmluZGV4MiA+PSBsaXN0Lmxlbmd0aCkgdGhpcy5pbmRleDIgPSAwO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICB1cGRhdGUoZHQpIHtcbiAgICAgICAgY29uc3Qgc2EgPSBjYy5MYWJlbC5fc2hhcmVBdGxhcztcbiAgICAgICAgaWYgKHNhKSB7XG4gICAgICAgICAgICBjYy5sb2coJ1NUT1JNIGNjIF5fXiA+PiAnLCBzYS5feCwgc2EuX3ksIE9iamVjdC5rZXlzKHNhLl9mb250RGVmRGljdGlvbmFyeS5fbGV0dGVyRGVmaW5pdGlvbnMpLmxlbmd0aCk7XG4gICAgICAgICAgICB0aGlzLnNob3cxLnN0cmluZyA9IFN0cmluZyhzYS5feCk7XG4gICAgICAgICAgICB0aGlzLnNob3cyLnN0cmluZyA9IFN0cmluZyhzYS5feSk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=
//------QC-SOURCE-SPLIT------
