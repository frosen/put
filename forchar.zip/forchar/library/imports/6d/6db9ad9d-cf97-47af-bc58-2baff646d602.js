"use strict";
cc._RF.push(module, '6db9a2dz5dHr7xYK6/2RtYC', 'NewScript');
// NewScript.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var list = [
    '这才叫肉 夹 馍通常情况下，麦当劳的每种菜品在量上都有相对明确的要求，以保证无论何时何地出品的食物都能质量趋于一致。而这次网友们买到的肉夹馍里的肉多少不一，很可能是因为作为一款新品上市过于匆忙，并没能制定出合理、严格的标准，导致你在不同的门店买的夹肉馍肉量完全看该店的良心或备餐师傅们的心情。每个鸡块的差别不会太大此后，麦当劳摆出了一副“有事好商量”的态度，在微博上表示肉馅的分量可能有所偏差',
    '666666沙拉酱和番茄酱，给汉堡化妆的部分就完成了。不过这还不够，和人一样，要想让它成为广告上的大明星，还得用P图软件给它美颜，去掉面包上的小孔，让它“皮肤细腻有光泽”才行。同样，蜂蜜从松饼上缓缓流下来的镜头看起来很诱人，但真的蜂蜜会被松饼吸收，留下一种神似尿床的印迹，因此聪明的摄影师们想到了用不会被吸收的机油来代替蜂蜜。而广告中啤酒和汽',
    '55555本质上是活在广告素材中的幻影，只要负责美美的就行了，“网络奔现”就别指望了~就拿汉堡来说，要做出广告中那样饱满挺拔的汉堡可不容易。首先要选不管好吃与否，至少严重超模、厚实匀称的粗大肉饼，再专门刷一层油上去让其更多汁、闪亮。然后摆好生菜和西红柿的位置，拿牙签固定住，分布必须符合黄金分割~最后用化妆棉给它穿个内增高，再拿针管在合适的位置挤上',
    '44444广告图与食物很一致就算是经常被网友调侃“封面欺诈”的康师傅也“洗心革面”，开了线下面馆，喊出口号就是要把包装上的红烧牛肉面端到你面前。那么如果足够努力，花多点钱，是不是有一天我们就能有机会吃到广告中那种令人垂涎的美食呢？很可惜，答案是不太可能！这样的巨无霸真的存在吗？广告中的那些美食虽然看起来令人垂涎欲滴、食欲大增，但很多其实根本就不存在',
    '999你说她为社会的进步贡献了多少。我的梦想就是要成为男版的咪蒙，通过骂女性走上人生巅峰。”“所以是为了挣钱？”——“小伙子，你的悟性很高嘛！要不要跟着我，我有个实习生一个月工资五万，我看你根骨不错，是个万中无一的练武奇才。”“好啊好啊，您用这一套去骂女性，等您骂完了，我照搬过来骂男性，这样我们就有挣不完的钱了！”——“对的，孺子可教，我们的想法，哪是那些凡夫俗子可以理解的。',
    '666我负责冒犯，观众负责艺术啊。现在都讲究线上线下结合，我负责在线上冒犯女性，观众在线下思考为什么是艺术”“可她们要是思考不出来，就光觉得被冒犯了呢？”——“你在说谁啊？谁觉得被冒犯了啊？”“观众啊？”——“什么观众？我又没冒犯观众。”“什么意思啊？你不是刚说了你是冒犯的艺术，你负责冒犯么？”——“你脑子有问题吧，我说的观众当然都是男观众了，女的消费能力还不如狗，谁把她们当观众啊。”“那你就不怕她们生气了抵制你、批评你、举报你',
    '444清华那位学姐的事做的真不地道。“——“哪位学姐，做了什么事？”“清华有个姑娘，学弟的包不小心扫到她屁股了，事儿还没调查清楚，她就要社会性死亡人家，后来看录像调查清楚了，说是要大家互相道歉，你说这算什么事儿啊。”——“女人嘛，都是那么普通，又那么自信的。““你怎么这么说话？“——“我怎么了，我不就说了句实话吗，我看你是对号入座，急了急了急了。石头砸小狗，谁叫谁小狗。““你能不能讲道理'
];
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label1 = null;
        _this.label2 = null;
        _this.show1 = null;
        _this.show2 = null;
        _this.btn1 = null;
        _this.btn2 = null;
        _this.index1 = 0;
        _this.index2 = 0;
        return _this;
    }
    NewClass.prototype.onLoad = function () {
        var _this = this;
        this.btn1.node.on('click', function () {
            _this.label1.string = list[_this.index1];
            _this.index1++;
            if (_this.index1 >= list.length)
                _this.index1 = 0;
        });
        this.btn2.node.on('click', function () {
            _this.label2.string = list[_this.index2];
            _this.index2++;
            if (_this.index2 >= list.length)
                _this.index2 = 0;
        });
    };
    NewClass.prototype.update = function (dt) {
        var sa = cc.Label._shareAtlas;
        if (sa) {
            cc.log('STORM cc ^_^ >> ', sa._x, sa._y);
            this.show1.string = String(sa._x);
            this.show2.string = String(sa._y);
        }
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label2", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show2", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn1", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn2", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();