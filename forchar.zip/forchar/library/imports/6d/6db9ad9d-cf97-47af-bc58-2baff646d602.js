"use strict";
cc._RF.push(module, '6db9a2dz5dHr7xYK6/2RtYC', 'NewScript');
// NewScript.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var list = [
    '这才叫肉 夹 馍通常情况下，麦当劳的每种菜品在量上都有相对明确的要求，以保证无论何时何地出品的食物都能质量趋于一致。而这次网友们买到的肉夹馍里的肉多少不一，很可能是因为作为一款新品上市过于匆忙，并没能制定出合理、严格的标准，导致你在不同的门店买的夹肉馍肉量完全看该店的良心或备餐师傅们的心情。每个鸡块的差别不会太大此后，麦当劳摆出了一副“有事好商量”的态度，在微博上表示肉馅的分量可能有所偏差',
    '666666沙拉酱和番茄酱，给汉堡化妆的部分就完成了。不过这还不够，和人一样，要想让它成为广告上的大明星，还得用P图软件给它美颜，去掉面包上的小孔，让它“皮肤细腻有光泽”才行。同样，蜂蜜从松饼上缓缓流下来的镜头看起来很诱人，但真的蜂蜜会被松饼吸收，留下一种神似尿床的印迹，因此聪明的摄影师们想到了用不会被吸收的机油来代替蜂蜜。而广告中啤酒和汽',
    '55555本质上是活在广告素材中的幻影，只要负责美美的就行了，“网络奔现”就别指望了~就拿汉堡来说，要做出广告中那样饱满挺拔的汉堡可不容易。首先要选不管好吃与否，至少严重超模、厚实匀称的粗大肉饼，再专门刷一层油上去让其更多汁、闪亮。然后摆好生菜和西红柿的位置，拿牙签固定住，分布必须符合黄金分割~最后用化妆棉给它穿个内增高，再拿针管在合适的位置挤上',
    '44444广告图与食物很一致就算是经常被网友调侃“封面欺诈”的康师傅也“洗心革面”，开了线下面馆，喊出口号就是要把包装上的红烧牛肉面端到你面前。那么如果足够努力，花多点钱，是不是有一天我们就能有机会吃到广告中那种令人垂涎的美食呢？很可惜，答案是不太可能！这样的巨无霸真的存在吗？广告中的那些美食虽然看起来令人垂涎欲滴、食欲大增，但很多其实根本就不存在',
    '999你说她为社会的进步贡献了多少。我的梦想就是要成为男版的咪蒙，通过骂女性走上人生巅峰。”“所以是为了挣钱？”——“小伙子，你的悟性很高嘛！要不要跟着我，我有个实习生一个月工资五万，我看你根骨不错，是个万中无一的练武奇才。”“好啊好啊，您用这一套去骂女性，等您骂完了，我照搬过来骂男性，这样我们就有挣不完的钱了！”——“对的，孺子可教，我们的想法，哪是那些凡夫俗子可以理解的。',
    '666我负责冒犯，观众负责艺术啊。现在都讲究线上线下结合，我负责在线上冒犯女性，观众在线下思考为什么是艺术”“可她们要是思考不出来，就光觉得被冒犯了呢？”——“你在说谁啊？谁觉得被冒犯了啊？”“观众啊？”——“什么观众？我又没冒犯观众。”“什么意思啊？你不是刚说了你是冒犯的艺术，你负责冒犯么？”——“你脑子有问题吧，我说的观众当然都是男观众了，女的消费能力还不如狗，谁把她们当观众啊。”“那你就不怕她们生气了抵制你、批评你、举报你',
    '444清华那位学姐的事做的真不地道。“——“哪位学姐，做了什么事？”“清华有个姑娘，学弟的包不小心扫到她屁股了，事儿还没调查清楚，她就要社会性死亡人家，后来看录像调查清楚了，说是要大家互相道歉，你说这算什么事儿啊。”——“女人嘛，都是那么普通，又那么自信的。““你怎么这么说话？“——“我怎么了，我不就说了句实话吗，我看你是对号入座，急了急了急了。石头砸小狗，谁叫谁小狗。““你能不能讲道理',
    '各位觉得这些人的言行想法是聪慧还是愚蠢？他们还会和路人辩论，振振有词，有些地方说的确实有些道理。这些人不是一个人，两个人，而是一个群体，可以称得上是"他们"了吧。也许你看了会不理解他们，嘲笑他们，但仔细想想，在某个时间阶段，或者某个大环境下，"我们"会不会也表现得像"他们"一样呢？你觉得事后"他们"会反思自己的行为么？',
    '如果"我们"也曾经做出过这样集体不理智的行为，事后"我们"是会反思自己，还是会说，那个时代就是那样的，亦或把所有问题都甩给一个或几个人？"我们"真的没有经历过这种事吗？其次，我写的这些东西并非为了批判谁，而且反思，批判是对别人，反思是对自己。评论区说我不要擅自代表他人这一点我是非常认可的。我说的"我们"包含我自己，但不包含在看的每一位读者。',
    '就好比，有部分人砸日本车、抢盐、把一切称赞外国的行为视为崇洋媚外……我自认也不是这些人，但这些现象和这些群体是客观存在的，看着"他们"我会想，也许在某些时候，我也像"他们"一样荒唐而不自知。同时，我想如果我生活在三体世界，出生在大低谷之后的时代，没体验过公元人亲眼见证地球与三体的科技代差，我可能也会像大多数人一样，认为人类必胜。',
    '如果我没有亲身经历过水滴团灭人类舰队给人类带来的绝望，也许我也会畏惧那个执掌着两个世界毁灭钥匙的罗辑，选择那个圣母一样的程心……哪怕我知道了逃跑是人类的唯一出路，也许我依然会选择整个人类在一起等待毁灭，而不是让少数精英、高层、有钱人……逃走……我，不代表任何人，但我知道，是有"我们"这个群体存在的，而且，"我们"哪怕错了，也未必会反思、悔改、认错……如果"我们"真的像伟人期许的那样，是时代的缔造者，是真正的英雄，也许"我们"应该意识到，"我"的言行，也是在影响改变着这个时代的，哪怕只是沧海一粟，萤火之光，每个人都承担着属于自己，属于这个时代的责任。时代的成功是"我们"的光荣，时代的某些错误，是要由造成这个错误的"我们"中的每一个"我"承担的，而不仅仅是某一个个体。',
    '————————以下为原文————————',
    '尽管我是那么的反感程心，但我还是想说一句冒天下之大不韪的话，也许《三体》中最渣的是"我们"。是"我们"被时代裹挟着，把叶文洁推到了墙角。是"我们"用石块处决了雷迪亚兹。是"我们"在基础物理被智子锁死的情况下，居然做着超越三体人的春秋大梦。是"我们"把"青铜时代号"和"蓝色空间号"视作叛徒。是"我们"把罗辑一次次的捧上神坛，推入地狱！是"我们"选出了程心！！！',
    '是啊，历史是由人民书写的，一切的荣耀都归功于人民。那么，差错呢？难道就推给一两个决定了人类历史走向的人么？没有叶文洁，三体人不会探测距离他们如此之近的星系么？没有ETO，三体人不会来侵略太阳系么？没有程心，一切都不会逝去，生命和文明就会取得胜利么？【“打倒反动学术权威叶哲泰！！”“打倒一切反动学术权威！！”“打倒一切反动学说！！”】',
    '【"得知消息后，恐惧压倒了一切，他决定牺牲叶文洁，保护自己。半个世纪后，历史学家们一致认为，1969年的这一事件是以后人类历史的一个转折点。"】【一路上很顺利，但一个多小时后还是有人认出了罗辑，于是车里的人一致要求他下车。罗辑争辩说自己已经输入信用点买了票，当然有权坐车。有一个头发花白的老者拿出两枚现在已经很不常见的现金硬币扔给了他，他还是被赶下了车。“面壁者，你背把铁锹干什么？”车开时有人从车窗探出头问。“为自己挖墓。”罗辑说，引起了车里的一阵哄笑。没人知道他说的是真话。】',
    '【漫长的使命已经最后完成，那最沉重的责任现在离开了他。以后，不管他在已经女性化的人类眼中是怎样的恶魔和怪物，人们都不得不承认，纵观文明史，他的胜利无人能及。】【人群瞬间寂静下来，人们抬头看着，那架可能烧死了几十人的穿梭机轰鸣着从停泊区升起，拖着白色的尾迹直上高空，然后转向东方。人们似乎不敢相信眼前发生的事。',
    '只过了十几秒钟，又一架穿梭机从停泊区起飞，这次距离他们更近，轰鸣、火光和热浪让人群由僵滞陷入极度的狂乱中。接下来，第三架，第四架……停泊区的穿梭机相继强行发射，',
    '团团烈焰中，焦黑的人体拖着烟火在空中横飞，停泊区变成了火葬场！】【“前面的，拦截它！撞死它！！”又是那个女人的声音，“啊！他们能达到逃逸速度，他们能逃掉！他们能活！！',
    '啊啊啊！！我要光速飞船！！拦住它呀！掐死里面的！！”】',
    '……读者们秉持着上帝视角，当然可以随意点评书中的人物和选择。但如果真的代入其中，我们真的会比"我们"做的更好吗？"我们"真的能逃避属于自己的那份责任，把一切都推给某个个体，这……难道不是渣吗？',
    '毛主席说："群众是真正的英雄！"只能享受胜利的果实，不能承受失败的酸楚，这算什么英雄呢？章北海、罗辑这些人类之光是"我们"孕育出来的，程心、伊文思同样是从"我们"中走出来的。',
    '站在上帝的视角，我们当然知道程心是错的，罗辑悟出的宇宙社会学是战胜三体人的理论基础，我们人类只有牺牲大多数，让少数人逃亡才得以延续文明的火种。',
    '但抛开全知的视角，"我们"能接受自己和自己的孩子成为"牺牲品"，让少数精英、资本家、权贵，飞向宇宙吗？"我们"抛弃罗辑这个掌握着两个世界命运之剑的老疯子，选择看起来人畜无害的身后程心，只为睡个安稳觉，让自己觉得过了今天还有明天，看起来有什么不对？',
    '"我们"为自己的选择付出了代价，最后"我们"只接受胜利喜悦，不承担失败的责任，"我们"真的不渣吗……通过这次疫情，现实中的一些"我们"与三体中的"我们"难道没有相似之处吗？',
    '疫情初期，人心惶惶，尽管只是少数，但不少人真的也视新冠为"武汉病毒"，排斥湖北的同胞。',
    '我们挺过来了，欧美在病毒面前败下阵来，又有多少人无视在经济、军事、科技、民生上的巨大差距，觉得我们已经赶欧超美了，容不下半点不同的声音，仿佛说国外好的地方就是崇洋媚外。',
    '面对钟南山教授这样的英雄，多少人在疫情的时候视他为救世主，又在他代言，为商品站台，支持中药的时候对他出言不逊……'
];
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label1 = null;
        _this.label2 = null;
        _this.show1 = null;
        _this.show2 = null;
        _this.btn1 = null;
        _this.btn2 = null;
        _this.index1 = 0;
        _this.index2 = 0;
        return _this;
    }
    NewClass.prototype.onLoad = function () {
        var _this = this;
        this.btn1.node.on('click', function () {
            _this.label1.string = list[_this.index1];
            _this.index1++;
            if (_this.index1 >= list.length)
                _this.index1 = 0;
        });
        this.btn2.node.on('click', function () {
            _this.label2.string = list[_this.index2];
            _this.index2++;
            if (_this.index2 >= list.length)
                _this.index2 = 0;
        });
    };
    NewClass.prototype.update = function (dt) {
        var sa = cc.Label._shareAtlas;
        if (sa) {
            cc.log('STORM cc ^_^ >> ', sa._x, sa._y, Object.keys(sa._fontDefDictionary._letterDefinitions).length);
            this.show1.string = String(sa._x);
            this.show2.string = String(sa._y);
        }
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label2", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show1", void 0);
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "show2", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn1", void 0);
    __decorate([
        property(cc.Button)
    ], NewClass.prototype, "btn2", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();